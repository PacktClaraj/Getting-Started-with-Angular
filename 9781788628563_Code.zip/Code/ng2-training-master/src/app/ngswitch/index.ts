export * from './ngswitch.component';
