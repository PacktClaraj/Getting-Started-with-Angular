import { Component } from '@angular/core';

@Component({
  selector: 'app-hiding',
  templateUrl: 'hiding.component.html'
})
export class HidingComponent {

  value;


}
