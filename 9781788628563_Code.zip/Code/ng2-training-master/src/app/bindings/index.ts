export * from './bindings.component';
