import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jasmine-test',
  templateUrl: './jasmine-test.component.html',
  styleUrls: ['./jasmine-test.component.css']
})
export class JasmineTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
