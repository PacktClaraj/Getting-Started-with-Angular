export * from './app.component';
export * from './app2.component';
export * from './helloWorld.component';
export * from './helloWorld2.component';
