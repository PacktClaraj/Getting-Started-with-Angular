export * from './hiding.component';
