import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
      <app-router></app-router>
  `
})
export class AppComponent {

}
