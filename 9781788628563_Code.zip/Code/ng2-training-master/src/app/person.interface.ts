/**
 * Created by AlaiCh on 7/26/2017.
 */
export interface Person {
  _id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  birthDate: Date | string;
}
